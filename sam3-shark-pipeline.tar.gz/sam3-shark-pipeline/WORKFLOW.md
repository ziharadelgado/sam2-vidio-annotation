# SAM 3 Shark Pipeline - Complete Workflow

## Visual Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    GOOGLE DRIVE (INPUT)                         │
│  gdrive:DeepSeaObjectDetection/rclone/queue/                   │
│                                                                 │
│  queue/                                                         │
│  ├── annotations.json  ← COCO format bounding boxes            │
│  └── images/                                                    │
│      ├── 00001.jpg                                              │
│      ├── 00002.jpg                                              │
│      └── ...                                                    │
└─────────────────────────────────────────────────────────────────┘
                              ↓
                    [bash scripts/sync_and_run.sh]
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                   UNITY HPC PROCESSING                          │
│                                                                 │
│  1. rclone downloads queue/ to Unity                            │
│  2. SLURM job starts on L40S GPU                                │
│  3. SAM 3 loads (facebook/sam3)                                 │
│  4. For each image:                                             │
│     • Read bounding boxes from JSON                             │
│     • Run SAM 3 with prompt "shark"                             │
│     • Convert boxes → segmentation masks                        │
│     • Export to YOLO format                                     │
│  5. rclone uploads results to Drive                             │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                   GOOGLE DRIVE (OUTPUT)                         │
│  gdrive:DeepSeaObjectDetection/rclone/processed/               │
│                                                                 │
│  processed/                                                     │
│  ├── images/                                                    │
│  │   ├── 00001.jpg                                              │
│  │   └── ...                                                    │
│  ├── labels/           ← YOLO segmentation format              │
│  │   ├── 00001.txt    → "0 x1 y1 x2 y2 x3 y3 ..."             │
│  │   └── ...                                                    │
│  └── data.yaml                                                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
                   [rclone download to laptop]
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                        ROBOFLOW                                 │
│                                                                 │
│  1. Upload → YOLO (Darknet) with segmentation                  │
│  2. Upload processed/ folder                                    │
│  3. Train SharkDetect-V4-seg                                    │
└─────────────────────────────────────────────────────────────────┘
```

## Step-by-Step Instructions

### Setup (One Time Only)

#### 1. Upload to GitHub

```bash
# On your laptop
cd /path/to/sam3-shark-pipeline
git init
git add .
git commit -m "Initial SAM 3 shark pipeline"
git branch -M main
git remote add origin https://github.com/ziharadelgado/sam3-shark-pipeline.git
git push -u origin main
```

#### 2. Clone on Unity

```bash
# SSH to Unity
ssh zihara_delgado_uri_edu@unity.uri.edu

# Clone repository
cd /home/zihara_delgado_uri_edu/
git clone https://github.com/ziharadelgado/sam3-shark-pipeline.git
cd sam3-shark-pipeline
```

#### 3. Setup Environment

```bash
# Submit setup job (creates conda env, installs dependencies)
sbatch scripts/setup_env.slurm

# Monitor progress (~30 minutes)
tail -f logs/setup_*.out

# When done, you should see: "✅ Setup Complete"
```

#### 4. Download SAM 3 Checkpoint

```bash
# First, login to HuggingFace
huggingface-cli login
# Paste your token from: https://huggingface.co/settings/tokens

# Request access to SAM 3
# Visit: https://huggingface.co/facebook/sam3
# Click "Request Access" and wait for approval (usually instant)

# Download checkpoint
bash scripts/download_sam3.sh

# Should see: "✓ SAM 3 checkpoint downloaded!"
```

### Running the Pipeline (Every Time)

#### 1. Prepare Your Data

Put your data in Google Drive at this exact path:
```
DeepSeaObjectDetection/rclone/queue/
├── annotations.json
└── images/
    ├── 00001.jpg
    └── ...
```

**IMPORTANT**: Check your `annotations.json` format:

```json
{
  "images": [
    {
      "id": 1,
      "file_name": "00001.jpg",
      "width": 1024,
      "height": 576
    }
  ],
  "annotations": [
    {
      "id": 1,
      "image_id": 1,
      "category_id": 1,
      "bbox": [x, y, width, height]
    }
  ],
  "categories": [
    {"id": 1, "name": "shark"}
  ]
}
```

**Test locally first** (optional but recommended):
```bash
python test_local.py /path/to/queue/
```

#### 2. Run Pipeline on Unity

```bash
# SSH to Unity
ssh zihara_delgado_uri_edu@unity.uri.edu

# Navigate to project
cd /home/zihara_delgado_uri_edu/sam3-shark-pipeline

# Run the pipeline (syncs + submits job)
bash scripts/sync_and_run.sh
```

This will:
1. Download queue from Google Drive to Unity
2. Submit SLURM job to GPU partition
3. Return job ID

#### 3. Monitor Job

```bash
# Check job status
squeue -u zihara_delgado_uri_edu

# Watch live output
tail -f logs/sam3_<jobid>.out

# Check for errors
tail -f logs/sam3_<jobid>.err
```

**Job stages you'll see:**
```
1. Syncing queue from Google Drive... (1-2 min)
2. Loading SAM 3 model... (30 sec)
3. Processing images... (depends on count)
4. Uploading results... (1-2 min)
5. ✅ Pipeline Complete
```

#### 4. Download Results

Results are automatically uploaded to:
```
gdrive:DeepSeaObjectDetection/rclone/processed/
```

**Download to your laptop:**

```bash
# On your laptop (or Unity login node)
rclone copy gdrive:DeepSeaObjectDetection/rclone/processed/ ./processed_local/ -v
```

You'll get:
```
processed_local/
├── images/
├── labels/
└── data.yaml
```

#### 5. Upload to Roboflow

1. Open your Roboflow project
2. Click **"Upload Data"**
3. Select format: **"YOLO (Darknet) with segmentation"**
4. Drag & drop the `processed_local/` folder
5. Click **"Finish Upload"**

Roboflow will automatically:
- Read `data.yaml`
- Match images with labels
- Import segmentation polygons
- Add to your dataset

### Troubleshooting

#### Job fails immediately

Check logs:
```bash
cat logs/sam3_<jobid>.err
```

Common issues:
- `annotations.json` not found → Check Google Drive path
- `SAM 3 checkpoint not found` → Run `bash scripts/download_sam3.sh`
- `rclone sync failed` → Test: `rclone ls gdrive:`

#### Job stuck in queue

```bash
squeue  # Check cluster status
sinfo   # Check partition availability
```

If stuck >30 min, cancel and resubmit:
```bash
scancel <jobid>
bash scripts/sync_and_run.sh
```

#### CUDA out of memory

This means your images are too large or there are too many objects.

Solutions:
1. Resize images to 1024×576 before uploading to Drive
2. Process in smaller batches
3. Edit `scripts/run_pipeline.slurm` to request more RAM:
   ```bash
   #SBATCH --mem=96G  # Increase from 60G
   ```

#### Poor segmentation quality

SAM 3 relies on the text prompt. Try different prompts:

Edit `scripts/run_pipeline.slurm` line 51:
```bash
--text-prompt "shark"              # Default
--text-prompt "Etmopterus"         # Specific genus
--text-prompt "lanternshark"       # Common name
--text-prompt "deep sea fish"     # More general
```

#### Results not uploading to Drive

Check rclone manually:
```bash
# Test upload
echo "test" > /tmp/test.txt
rclone copy /tmp/test.txt gdrive:DeepSeaObjectDetection/rclone/test/

# Check it appears
rclone ls gdrive:DeepSeaObjectDetection/rclone/test/
```

If fails, reconfigure:
```bash
rclone config
```

### Performance Notes

- **L40S GPU**: ~10-20 images/minute
- **SAM 3 model size**: 3.5GB VRAM
- **Typical job**: 100 images = ~10 minutes
- **Large batch**: 1000 images = ~1-2 hours

### Customization

#### Different animal/object

Edit `scripts/run_pipeline.slurm`:
```bash
--text-prompt "whale shark"
--text-prompt "coral reef"
--text-prompt "submarine"
```

#### Different input/output locations

Edit `scripts/run_pipeline.slurm`:
```bash
GDRIVE_QUEUE="gdrive:MyProject/input/"
GDRIVE_OUTPUT="gdrive:MyProject/output/"
```

#### Process specific frames from video

If your input is video frames, you can filter:

1. Extract specific frames first
2. Create `annotations.json` for those frames only
3. Upload to queue/

### Git Workflow

When you improve the code:

```bash
# On Unity
cd /home/zihara_delgado_uri_edu/sam3-shark-pipeline
git add .
git commit -m "Improved segmentation quality"
git push

# To update from GitHub
git pull
```

### Clean Up

After processing, clean up to save space:

```bash
# Remove queue (but keep checkpoint!)
rm -rf /home/zihara_delgado_uri_edu/queue/*

# Remove old processed results
rm -rf /home/zihara_delgado_uri_edu/processed/*

# Keep: sam3-shark-pipeline/ and checkpoints/
```

### Support

If you get stuck:
1. Check logs in `logs/sam3_*.out` and `logs/sam3_*.err`
2. Test locally with `python test_local.py`
3. Verify Google Drive structure
4. Check that SAM 3 checkpoint exists
5. Ask Professor Mandal or Kamron for Unity help

## Quick Reference

```bash
# One-time setup
sbatch scripts/setup_env.slurm
bash scripts/download_sam3.sh

# Every run
bash scripts/sync_and_run.sh

# Monitor
squeue -u $USER
tail -f logs/sam3_*.out

# Download results
rclone copy gdrive:DeepSeaObjectDetection/rclone/processed/ ./local/ -v
```
